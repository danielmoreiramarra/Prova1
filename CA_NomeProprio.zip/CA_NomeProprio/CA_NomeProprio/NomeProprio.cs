﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caVetor2D
{
    internal class NomeProprio
    {
        // atributos
        public string nome_completo;
        public string nome_paper;

        // métodos
        public NomeProprio() // construtor default - aridade 0
        {
            nome_completo = string.Empty;
            nome_paper = string.Empty;
        }

        public void ImprimeNomePaper()
        {
            Console.WriteLine(nome_paper);
        }

        public NomeProprio(string primeiro_nome, string nome_do_meio, string sobrenome)
        {
            this.nome_completo = primeiro_nome + " " + nome_do_meio + " " + sobrenome;
            this.nome_paper = sobrenome + "," + " " + nome_do_meio[0] + "." + " " + primeiro_nome;
        }
    } // fim da classe NomeProprio
}

