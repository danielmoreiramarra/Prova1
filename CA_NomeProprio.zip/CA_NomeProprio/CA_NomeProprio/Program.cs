﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace CA_NomeProprio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NomeProprio nome = Console.ReadLine();
            nome.ImprimeNomePaper();
            Console.ReadLine();
        }
    }
}
