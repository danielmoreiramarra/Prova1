﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Math;

namespace CA_NumComplexo
{
    internal class NumComplexo
    {
        // atributos
        public double Re;
        public double Im;

        // métodos
        public NumComplexo() // construtor default - aridade 0
        {
            Re = 0;
            Im = 0;
        }

        public NumComplexo(double _re, double _im)
        {
            this.Re = _re;
            this.Im = _im;
        }
        double num = 2^2;


        public double Modulo()
        {
            return (Math.Sqrt(Math.Pow(this.Re,2) + Math.Pow(this.Im, 2)));
        }

        public double Argumento()
        {
            return (Math.Atan(this.Im/this.Re));
        }

        public NumComplexo soma(NumComplexo num)
        {
            NumComplexo Soma = new NumComplexo();
            Soma.Re = this.Re + num.Re;
            Soma.Im = this.Im + num.Im;

            return (Soma);
        }

        public NumComplexo vezes(NumComplexo num)
        {
            NumComplexo Produto = new NumComplexo();
            Produto.Re = this.Re*num.Re - this.Im*num.Im;
            Produto.Im = this.Re*num.Im + this.Im*num.Re;

            return (Produto);
        }

        public void ImprimeFormaPolar()
        {
            Console.WriteLine(this.Modulo() + "(cos" + this.Argumento() + "isen" + this.Argumento() + ")");
        }
    } // fim da classe NumComplexo
}
