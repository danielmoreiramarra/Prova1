﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace CA_NumComplexo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            NumComplexo z_1 = new NumComplexo(1, 1);
            NumComplexo z_2 = new NumComplexo(3, -1);

            NumComplexo c = z_1.soma(z_2);
            NumComplexo d = z_1.vezes(z_2);

            Console.WriteLine("Forma polar da soma z1 + z2 = ");
            c.ImprimeFormaPolar();
            Console.WriteLine("Forma polar do produto z1 * z2 = ");
            d.ImprimeFormaPolar();

            Console.ReadLine();
        }
    }
}